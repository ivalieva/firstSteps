import UIKit
//strings
let y = "Hello"
let z = "world"
z + y
/*
// operators +=, -=
var c = 1
c += 2 // c = c + 2
c -= 2 // c = c - 2
// operators ==, !=, >, <, >= , <= return Bool
let t = 15
let p = 10
t == p
t != p
t > p
t < p
t >= p
t <= p
// if else operator
let name = "world"
if name == "world"{
    print("hello world")
} else{
    print("something is wrong")
}
/* ternary operator
 if condition {
 action 1
 } else {
 action2
 }
*/
let r = 45
let v = 49
if r == v {
    print("T!")
} else {
    print("F!")
}
r == v ? print("T!") : print("F!")
r != v ? print("true") : print ("false")
// closed (a...b) and semiclosed (a..<b) operator
//Logical operators !a, && (and), || (or)
let d = true
if !d {
    print("great")
} else {
    print("what can I do for you")
}
// true && true = true, false && true = false
let isABig = true
if d && isABig {
    print("cool")
} else {
    print("bad")
}
// true OR false = true, false OR false = false
if d || isABig {
    print("yes it is")
} else {
    print("no it's not")
}
*/

